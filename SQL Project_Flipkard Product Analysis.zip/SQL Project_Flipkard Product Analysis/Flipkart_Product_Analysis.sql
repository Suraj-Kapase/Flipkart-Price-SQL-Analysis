-- 1st Project

create database FlipKart_Product;
use FlipKart_Product;
select * from flipkart_products_20250405;

select * from fk;

-- 1) Top 10 highest-rated products
Select `Product Name`, `Rating (â˜…)` from fk
order by `Rating (â˜…)` desc
limit 10;

-- 2) Which products have the highest discount in each sub-category?
select `Sub Category`,`Product Name`, max(`Discount (%)`) from fk
group by `Sub Category`,`Product Name`;

-- 3) List all products with rating above 4.5 and at least 1000 buyers
select `Product Name`, `Rating (â˜…)`, `Number of Buyers` from fk
where `Rating (â˜…)` > 4.5 AND `Number of Buyers` >= 1000;

-- 4. Calculate revenue per product (Price (₹) * Total Sold)
select `Product Name`, (`Price (â‚¹)`*`Total Sold`) as Revenue from fk;

-- 5. Find top 5 sub-categories by total units sold
select `Sub Category`, sum(`Total Sold`) as `Total Unit Sold` from fk
group by `Sub Category`
order by `Total Unit Sold` desc
limit 5;

-- 6. Identify products with stock less than 10% of total sold (low inventory alert)
select `Product Name`, `Total Sold`, `Available Stock`, ((`Available Stock`*100)/`Total Sold`) as `low inventory` from fk
where ((`Available Stock`*100)/`Total Sold`)<10
order by `low inventory` desc;

-- 7. Average rating and average price for each sub-category
select `Sub Category`, round(avg(`Rating (â˜…)`),2) as AVG_Rating, round(avg(`Price (â‚¹)`),2) as AVG_Price from fk
group by `Sub Category`;

-- 8. Which main category has the highest average discount?
select `Main Category`, avg(`Discount (%)`) as AVG_Disc from fk
group by `Main Category`
order by AVG_Disc desc
limit 1;

-- 9. Which sellers have the most listed products?
select `Seller`, count(`Product Name`) as Product_Count from fk
group by `Seller`
order by Product_Count desc;

-- 10. Average product rating and sales per seller
select `Seller`, avg(`Rating (â˜…)`) as Avg_Rating, sum(`Price (â‚¹)`*`Total Sold`) as Sales from fk
group by `Seller`
order by Sales desc;

--  11. Do products with return policy have higher average ratings or sales?
select `Return Policy`, avg(`Rating (â˜…)`) as Avg_Rating, avg(`Price (â‚¹)`*`Total Sold`) as Sales from fk
group by `Return Policy`;

-- 12. List products from specific sellers with a return policy that link to Flipkart URLs (conidering Seller as 'Flipkart Assured' & 'ElectroWorld')
select `Seller`, `Product Name`, `Return Policy`, `Product URL` from fk
where `Return Policy`="True" and `Seller` in ("Flipkart Assured","ElectroWorld");
